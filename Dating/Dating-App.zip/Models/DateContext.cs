﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Dating.Models
{
    public partial class DateContext : DbContext
    {
        public DateContext()
        {
        }

        public DateContext(DbContextOptions<DateContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Hobby> Hobby { get; set; }
        public virtual DbSet<Hobbylist> Hobbylist { get; set; }
        public virtual DbSet<Users> Users { get; set; }

        /* protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
         {
          /*   if (!optionsBuilder.IsConfigured)
             {
 #warning /*To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                 optionsBuilder.UseSqlServer("Data Source=SUMEETHKUMAR\\SQLEXPRESS;Database=Date;Integrated Security=True;");
                }
        } */

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Hobby>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("hobby");

                entity.Property(e => e.Hobby1)
                    .IsRequired()
                    .HasColumnName("hobby")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.HobbyId).HasColumnName("hobby_id");
            });

            modelBuilder.Entity<Hobbylist>(entity =>
            {
                entity.ToTable("hobbylist");

                entity.Property(e => e.HobbylistId)
                    .HasColumnName("hobbylist_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.HobbyId).HasColumnName("hobby_id");

                entity.Property(e => e.UserId).HasColumnName("user_id");
            });

            modelBuilder.Entity<Users>(entity =>
            {
                entity.HasKey(e => e.UserId);

                entity.Property(e => e.UserId)
                    .HasColumnName("user_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.Age).HasColumnName("age");

                entity.Property(e => e.Cname)
                    .HasColumnName("cname")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Occupation)
                    .IsRequired()
                    .HasColumnName("occupation")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Phone).HasColumnName("phone");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
