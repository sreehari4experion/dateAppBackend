﻿using System;
using System.Collections.Generic;

namespace Dating.Models
{
    public partial class Users
    {
        public int UserId { get; set; }
        public string Cname { get; set; }
        public int? Age { get; set; }
        public string Occupation { get; set; }
        public long? Phone { get; set; }
    }
}
