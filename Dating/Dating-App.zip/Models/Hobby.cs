﻿using System;
using System.Collections.Generic;

namespace Dating.Models
{
    public partial class Hobby
    {
        public int HobbyId { get; set; }
        public string Hobby1 { get; set; }
    }
}
