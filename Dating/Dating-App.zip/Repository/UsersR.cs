﻿using Dating.Models;
using Dating.View_Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dating.Repository
{
    public class UsersR : IUsers
    {
        private readonly DateContext _contextone;
        public UsersR(DateContext contextone)
        {
            _contextone = contextone;
        }

        public async Task<string> GetMostHobby()
        {
      
                if (_contextone != null)
                {

                return " " + await (
                        from c in _contextone.Hobby
                        join
                        h in _contextone.Hobbylist
                        on c.HobbyId equals h.HobbyId
                        group c.Hobby1 by c.Hobby1 into grp
                        orderby grp.Count() descending
                        select grp.Key).FirstOrDefaultAsync(); 
             

                }
            return null;

            }

        public async Task<List<UserView>> GetUsers()
        {
            
            if (_contextone != null)
            {
                return await (
                              from p in _contextone.Users
                              select new UserView
                              {
                                  Users1 = p.UserId,
                                  Name = p.Cname,
                                  Phone = p.Phone,
                                  Occupation = p.Occupation,
                                  Hobby = (from c in _contextone.Hobby
                                           join
                                           h in _contextone.Hobbylist
                                           on c.HobbyId equals h.HobbyId
                                           where h.UserId == p.UserId
                                           select c.Hobby1).ToList()


            }).ToListAsync();  //FirstorDefaultAsync();
            }
            return null;
        }
    }
}
