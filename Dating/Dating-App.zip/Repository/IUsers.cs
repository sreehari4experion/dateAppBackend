﻿using Dating.View_Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dating.Repository
{
    public interface IUsers
    {
        Task<List<UserView>> GetUsers();
        Task<string> GetMostHobby();
        //Task<UserView> GetUserbyId(int id);
       // Task<UserView> GetUserbyUsername(string username);

       // Task<UserView> GetUserbyPhone(long phone);
    }
}
