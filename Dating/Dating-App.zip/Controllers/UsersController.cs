﻿using Dating.Repository;
using Dating.View_Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dating.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IUsers _userR;

        //constructor injection
    public UsersController(IUsers user)
        { 
            _userR = user;
        }
        [HttpGet]
       // [Authorize]
        [Route("GetUsers")]
        public async Task<List<UserView>> GetUsers()
        {
            return await _userR.GetUsers();
        }
        [HttpGet]
       // [Authorize]
        [Route("GetMostHobby")]
        public async Task<string> GetMostHobby()
        {
            return await _userR.GetMostHobby();
        }

    }
}
